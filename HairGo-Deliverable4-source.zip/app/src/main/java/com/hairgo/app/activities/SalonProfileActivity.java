package com.hairgo.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.firebase.Timestamp;
import com.hairgo.app.R;
import com.hairgo.app.adapters.ReviewAdapter;
import com.hairgo.app.adapters.ServiceAdapter;
import com.hairgo.app.firebase.BookingManager;
import com.hairgo.app.firebase.ReviewManager;
import com.hairgo.app.firebase.SalonManager;
import com.hairgo.app.fragments.ReportProblemBottomSheet;
import com.hairgo.app.models.Salon;
import com.hairgo.app.models.ServiceDetail;
import com.hairgo.app.utils.ReviewLoader;
import com.hairgo.app.utils.SalonHours;
import com.hairgo.app.utils.SalonPhotos;
import com.hairgo.app.utils.Snackbars;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class SalonProfileActivity extends AppCompatActivity {

    private static final String TAG = "SalonProfileActivity";

    /** How far ahead to look for a free day before giving up on showing a date. */
    private static final int AVAILABILITY_LOOKAHEAD_DAYS = 30;

    private ProgressBar progress;
    private View contentGroup;
    private String salonId;
    private boolean salonLoaded;
    private ReviewAdapter reviewPreviewAdapter;

    /** This salon's own opening hours; defaults to 09:00–18:00 until the document loads. */
    private SalonHours salonHours = SalonHours.defaults();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salon_profile);

        salonId = getIntent().getStringExtra("salonId");

        ImageButton backBtn = findViewById(R.id.header).findViewById(R.id.btnBack);
        backBtn.setOnClickListener(v -> onBackPressed());

        progress = findViewById(R.id.progress);
        contentGroup = findViewById(R.id.contentGroup);

        if (salonId == null || salonId.isEmpty()) {
            showMissingSalon();
            return;
        }

        progress.setVisibility(View.VISIBLE);
        contentGroup.setVisibility(View.INVISIBLE);

        new SalonManager().getSalonById(salonId, new SalonManager.SalonDataCallback() {
            @Override
            public void onSuccess(Map<String, Object> salonData) {
                Salon salon = toSalon(salonId, salonData);
                if (salon == null) {
                    showMissingSalon();
                    return;
                }
                salonLoaded = true;
                salonHours = SalonHours.fromDoc(salonData);
                // Read the services with their price and duration. Old salons
                // only have names saved, and those still work.
                List<ServiceDetail> serviceDetails = SalonManager.getServiceDetails(salonData);
                bindSalon(salon, serviceDetails);
                loadSalonPhoto();
                loadNextAvailableDate(salonId);
            }

            @Override
            public void onFailure(String errorMessage) {
                showMissingSalon();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Returning from booking or cancellation: refresh the "Next available"
        // line. Skipped on first open because onCreate already loads it.
        if (salonLoaded) {
            loadNextAvailableDate(salonId);
        }
    }

    /**
     * Converts the raw Firestore map into our Salon model. Every field is
     * null-checked because a document is allowed to be missing any of them.
     */
    private Salon toSalon(String salonId, Map<String, Object> data) {
        if (data == null) return null;

        Object name = data.get("name");
        if (name == null || name.toString().trim().isEmpty()) return null;

        Object location = data.get("location");
        double avgRating = 0.0;
        Object ratingValue = data.get("avgRating");
        if (ratingValue instanceof Number) {
            avgRating = ((Number) ratingValue).doubleValue();
        }

        List<String> services = new ArrayList<>();
        Object servicesValue = data.get("services");
        if (servicesValue instanceof List) {
            for (Object item : (List<?>) servicesValue) {
                if (item != null) services.add(item.toString());
            }
        }

        return new Salon(salonId, name.toString(),
                location == null ? "" : location.toString(),
                avgRating, services);
    }

    private void bindSalon(Salon salon, List<ServiceDetail> serviceDetails) {
        progress.setVisibility(View.GONE);
        contentGroup.setVisibility(View.VISIBLE);

        TextView headerTitle = findViewById(R.id.header).findViewById(R.id.tvHeaderTitle);
        headerTitle.setText(salon.getName());

        TextView tvSalonName = findViewById(R.id.tvSalonName);
        TextView tvSalonLocation = findViewById(R.id.tvSalonLocation);
        TextView tvSalonRating = findViewById(R.id.tvSalonRating);

        tvSalonName.setText(salon.getName());
        tvSalonLocation.setText(salon.getLocation());
        tvSalonRating.setText(String.format(Locale.getDefault(), "%.1f", salon.getAvgRating()));

        RecyclerView rvServices = findViewById(R.id.rvServices);
        rvServices.setLayoutManager(new LinearLayoutManager(this));
        rvServices.setAdapter(new ServiceAdapter(serviceDetails));

        setupReviewPreview(salon.getSalonId(), salon.getAvgRating());

        findViewById(R.id.btnBook).setOnClickListener(v -> {
            Intent intent = new Intent(this, BookAppointmentActivity.class);
            intent.putExtra("salonId", salon.getSalonId());
            startActivity(intent);
        });

        // Report the salon to the platform, pre-filled with this salon.
        findViewById(R.id.btnReportSalon).setOnClickListener(v ->
                ReportProblemBottomSheet
                        .newInstanceForSalon(salon.getSalonId(), salon.getName(), null)
                        .show(getSupportFragmentManager(), "report_problem"));
    }

    private void setupReviewPreview(String salonId, double storedAvgRating) {
        RecyclerView rvReviewPreview = findViewById(R.id.rvReviewPreview);
        rvReviewPreview.setLayoutManager(new LinearLayoutManager(this));
        reviewPreviewAdapter = new ReviewAdapter(true);
        rvReviewPreview.setAdapter(reviewPreviewAdapter);

        findViewById(R.id.tvSalonRating).setOnClickListener(v -> openReviews());
        findViewById(R.id.tvSeeAllReviews).setOnClickListener(v -> openReviews());

        loadReviewPreview(salonId, storedAvgRating);
    }

    private void openReviews() {
        if (salonId == null || salonId.isEmpty()) return;
        Intent intent = new Intent(this, SalonReviewsActivity.class);
        intent.putExtra("salonId", salonId);
        startActivity(intent);
    }

    /**
     * Shows the three newest reviews under the services. A short row of stars
     * and the count is enough for the profile; the full list opens separately.
     */
    private void loadReviewPreview(String salonId, double storedAvgRating) {
        ProgressBar previewProgress = findViewById(R.id.previewReviewsProgress);
        TextView tvPreviewEmpty = findViewById(R.id.tvPreviewEmpty);
        RecyclerView rvPreview = findViewById(R.id.rvReviewPreview);
        TextView tvSeeAll = findViewById(R.id.tvSeeAllReviews);
        TextView tvSalonRating = findViewById(R.id.tvSalonRating);

        previewProgress.setVisibility(View.VISIBLE);
        tvPreviewEmpty.setVisibility(View.GONE);
        rvPreview.setVisibility(View.GONE);
        tvSeeAll.setVisibility(View.GONE);

        ReviewLoader.load(salonId, new ReviewLoader.Callback() {
            @Override
            public void onLoaded(List<ReviewLoader.Item> reviews, boolean fromCache) {
                if (isFinishing() || isDestroyed()) return;
                previewProgress.setVisibility(View.GONE);

                if (reviews == null || reviews.isEmpty()) {
                    tvSalonRating.setText(R.string.no_reviews_yet);
                    tvPreviewEmpty.setText(R.string.no_reviews_yet);
                    tvPreviewEmpty.setVisibility(View.VISIBLE);

                    // The reviews are the truth, so remove a rating left behind
                    // by reviews that were deleted outside this screen.
                    if (!fromCache && Math.abs(storedAvgRating) > 0.01) {
                        new ReviewManager().updateSalonRating(salonId, 0.0);
                    }
                    return;
                }

                double average = ReviewLoader.averageRating(reviews);
                tvSalonRating.setText(String.format(Locale.getDefault(), "%.1f", average));

                // Repair the home-list copy when it does not match the reviews.
                if (!fromCache && Math.abs(average - storedAvgRating) > 0.01) {
                    new ReviewManager().updateSalonRating(salonId, average);
                }

                int previewSize = Math.min(3, reviews.size());
                reviewPreviewAdapter.setReviews(reviews.subList(0, previewSize));
                rvPreview.setVisibility(View.VISIBLE);
                tvSeeAll.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFailure(String errorMessage) {
                if (isFinishing() || isDestroyed()) return;
                previewProgress.setVisibility(View.GONE);
                Log.w(TAG, "Could not load reviews: " + errorMessage);
                tvPreviewEmpty.setText(R.string.reviews_load_failed);
                tvPreviewEmpty.setVisibility(View.VISIBLE);
            }
        });
    }

    /**
     * Swaps the default scissors icon for the salon's uploaded photo when it
     * has one. The padding and teal tint only make sense for the vector
     * placeholder, so they are cleared once a real photo is shown.
     */
    private void loadSalonPhoto() {
        SalonPhotos.fetchPhoto(salonId, bitmap -> {
            if (bitmap == null || isFinishing() || isDestroyed()) return;
            ShapeableImageView pfp = findViewById(R.id.ivSalonPfp);
            pfp.setImageBitmap(bitmap);
            pfp.setBackground(null);
            pfp.setImageTintList(null);
            pfp.setScaleType(ImageView.ScaleType.CENTER_CROP);
        });
    }

    /**
     * Shows the earliest slot the salon can actually be booked for.
     *
     * <p>The value comes from the same rules as the booking screen: the
     * salon's own per-day opening hours and 30-minute grid, the same
     * "cancelled/expired do not hold a slot" filter, and the same
     * minimum-notice window — so this line can never advertise a day while the
     * picker refuses it, or hide a day the picker offers.
     *
     * <p>The row stays hidden if the lookup fails, for example when the
     * composite index on salonID + isDeleted + dateTime has not been created.
     */
    private void loadNextAvailableDate(String salonId) {
        MaterialCardView cardNextAvailable = findViewById(R.id.tvNextAvailable);
        TextView tvNextAvailableText = (TextView) ((ViewGroup) cardNextAvailable.getChildAt(0)).getChildAt(1);
        cardNextAvailable.setVisibility(View.GONE);

        Calendar startOfToday = Calendar.getInstance();
        startOfToday.set(Calendar.HOUR_OF_DAY, 0);
        startOfToday.set(Calendar.MINUTE, 0);
        startOfToday.set(Calendar.SECOND, 0);
        startOfToday.set(Calendar.MILLISECOND, 0);

        new BookingManager().getFutureBookingsForSalon(salonId, startOfToday.getTime(),
                new BookingManager.BookingListCallback() {
                    @Override
                    public void onSuccess(List<Map<String, Object>> bookings) {
                        LocalDateTime next = findNextFreeSlot(bookings);
                        DateTimeFormatter formatter =
                                DateTimeFormatter.ofPattern("EEE d MMM, hh:mm a", Locale.getDefault());
                        if (next == null) {
                            tvNextAvailableText.setText(getString(
                                    R.string.salon_no_available_slots, AVAILABILITY_LOOKAHEAD_DAYS));
                        } else {
                            tvNextAvailableText.setText(getString(
                                    R.string.salon_next_available, next.format(formatter)));
                        }
                        cardNextAvailable.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onFailure(String errorMessage) {
                        // Availability is extra information, so a failed lookup
                        // leaves the rest of the screen working.
                        Log.w(TAG, "Could not load availability for salon " + salonId
                                + ": " + errorMessage);
                    }
                });
    }

    /**
     * Walks forward from today and returns the first slot that is not held by a
     * booking and is at least BookingManager.MIN_NOTICE_MINUTES away — i.e. the
     * first slot the booking screen would actually offer — or null if the
     * lookahead window has nothing bookable left.
     */
    private LocalDateTime findNextFreeSlot(List<Map<String, Object>> bookings) {
        Set<String> heldSlots = new HashSet<>();

        if (bookings != null) {
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
            for (Map<String, Object> booking : bookings) {
                if (booking == null) continue;
                Object dateTime = booking.get("dateTime");
                Date date = null;
                if (dateTime instanceof Timestamp) date = ((Timestamp) dateTime).toDate();
                else if (dateTime instanceof Date) date = (Date) dateTime;
                if (date == null) continue;

                heldSlots.add(toDayKey(date) + " " + timeFormat.format(date));
            }
        }

        // Same cutoff as the booking screen: nothing before now + notice.
        LocalDateTime cutoff =
                LocalDateTime.now().plusMinutes(BookingManager.MIN_NOTICE_MINUTES);

        LocalDate today = LocalDate.now();
        for (int offset = 0; offset < AVAILABILITY_LOOKAHEAD_DAYS; offset++) {
            LocalDate day = today.plusDays(offset);
            // java.time counts Monday as 1; SalonHours uses Calendar numbering
            // where Sunday is 1. Closed days simply yield no slots.
            int calendarDay = day.getDayOfWeek().getValue() % 7 + 1;
            for (String slot : salonHours.slotsFor(calendarDay)) {
                String[] parts = slot.split(":");
                LocalDateTime candidate = LocalDateTime.of(day,
                        LocalTime.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1])));
                if (candidate.isBefore(cutoff)) continue;
                if (!heldSlots.contains(day + " " + slot)) return candidate;
            }
        }
        return null;
    }

    private String toDayKey(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return String.format(Locale.US, "%04d-%02d-%02d",
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.DAY_OF_MONTH));
    }

    private void showMissingSalon() {
        progress.setVisibility(View.GONE);
        Snackbars.showThen(findViewById(android.R.id.content),
                R.string.salon_not_found, this::finish);
    }
}
